const newsController = require("../controllers/newsController");
const permission = require("../permissions");
const express = require('express');
const router = express.Router();

// Create News program (admin & staff)
router.post("/", newsController.createNews);

module.exports = router;
