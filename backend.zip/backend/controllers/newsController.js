const { News } = require("../models/News");
const { UserMongo } = require('../models/User');
const path = require('path');

// Create News
exports.createNews = async (req, res) => {
    try {
        const { title, text } = req.body;

        if (!title || !text) {
            return res.status(400).json({ message: 'Title and text are required fields.' });
        }

        const user = await UserMongo.findById(req.user);
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }

        if (req.files && req.files.image) {
            let fileName = Date.now().toString() + req.files.image.name;
            const __dirname = path.dirname(require.main.filename);

            req.files.image.mv(path.join(__dirname, 'uploads', fileName));

            const newNewsWithImage = new News({
                username: user.username,
                title,
                text,
                imgUrl: fileName,
                author: req.userId,
            });

            await newNewsWithImage.save();
            user.News.addToSet(newNewsWithImage);
            await user.save();

            return res.json(newNewsWithImage);
        }

        const NewsWithoutImage = new News({
            username: user.username,
            title,
            text,
            imgUrl: '',
            author: req.userId,
        });

        await NewsWithoutImage.save();
        user.News.addToSet(NewsWithoutImage);
        await user.save();

        return res.json(NewsWithoutImage);
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: 'Internal Server Error.' });
    }
};
